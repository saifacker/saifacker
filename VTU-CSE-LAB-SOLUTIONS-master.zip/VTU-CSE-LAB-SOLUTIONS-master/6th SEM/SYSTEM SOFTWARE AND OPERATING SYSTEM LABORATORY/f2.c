#include<stido.h>

int main()
{
	printf("hello");
}