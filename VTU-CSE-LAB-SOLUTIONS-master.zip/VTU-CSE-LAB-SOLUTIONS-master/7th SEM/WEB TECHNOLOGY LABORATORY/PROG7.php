<head>
	<meta http-equiv="refresh" content="1"/>
	<style>
		p {
			color:yellow;
			font-size:90px;
			position:absolute;
			top: 40%;
			left: 50%;
			transform: translate(-50%, -50%);
		}
		body {
			background-color:maroon;
		}
	</style>
	<p> <?php echo date(" h: i : s A");?> </p>
</head>